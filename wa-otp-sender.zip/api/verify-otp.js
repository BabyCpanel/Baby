import { verifyOTP } from '../lib/otp.js';

export default async (req, res) => {
  const { phone, code } = await req.json();
  const valid = verifyOTP(phone, code);
  res.json({ success: valid });
};
