import { setOTP } from '../lib/otp.js';
import { sendOTP } from '../lib/wa.js';

export default async (req, res) => {
  const { phone } = await req.json();
  const code = Math.floor(1000 + Math.random() * 9000).toString();
  setOTP(phone, code);
  await sendOTP(phone, code);
  res.json({ success: true });
};
