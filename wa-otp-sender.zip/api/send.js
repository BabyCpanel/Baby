import { verifyOTP } from '../lib/otp.js';
import { sendPesan } from '../lib/wa.js';

export default async (req, res) => {
  const { phone, targets, message } = await req.json();
  if (!verifyOTP(phone, null)) return res.status(403).json({ message: 'Belum verifikasi!' });
  await sendPesan(phone, targets, message);
  res.json({ message: 'Pesan dikirim!' });
};
