module.exports = {
  BOT_TOKEN: "",
  APIKEY: "Btz-eIMYQ" // APIKEY ini adalah fitur opsional. Jika ingin membuat APIKEY, kunjungi: https://api.betabotz.eu.org/users/login
};